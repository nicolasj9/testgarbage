import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corpus',
  templateUrl: './corpus.component.html',
  styleUrls: ['./corpus.component.css']
})
export class CorpusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
